import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  emailLogin:string ='E-mail';
  senhaLogin:string ='Senha';
  emailCadastro:string='E-mail';
  senhaCadastro:string='Senha';
  confirmaSenha:string='Confirme sua senha';
  user:string='Nome de Usuário';
  termosDeUso:boolean = false;

  constructor() { }

  ngOnInit(): void {
  }
  termosAceito()
  {
    this.termosDeUso = !this.termosDeUso;
  }
  limparEmailLogin()
  {
    this.emailLogin = '';
  }
}
